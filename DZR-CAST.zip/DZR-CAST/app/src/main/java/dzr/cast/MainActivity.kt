package dzr.cast

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.ImageView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.content.ContextCompat
import com.google.android.material.chip.ChipGroup
import com.google.android.material.materialswitch.MaterialSwitch
import java.net.Inet4Address
import java.net.NetworkInterface

class MainActivity : AppCompatActivity() {

    // Navigation & Panels
    private lateinit var panelMirror: View
    private lateinit var panelRecorder: View
    private lateinit var panelTikTok: View
    private lateinit var tvBadgeState: TextView

    private lateinit var iconNavMirror: ImageView
    private lateinit var txtNavMirror: TextView
    private lateinit var iconNavRecorder: ImageView
    private lateinit var txtNavRecorder: TextView
    private lateinit var iconNavTikTok: ImageView
    private lateinit var txtNavTikTok: TextView

    // Mirroring controls
    private lateinit var cgMirrorRes: ChipGroup
    private lateinit var cgMirrorFps: ChipGroup
    private lateinit var cgMirrorQ: ChipGroup
    private lateinit var swMirrorAudio: MaterialSwitch
    private lateinit var tvMirrorEstimate: TextView
    private lateinit var btnStartMirror: AppCompatButton
    private lateinit var btnStopMirror: AppCompatButton
    private lateinit var cardMirrorLink: View
    private lateinit var tvMirrorUrl: TextView

    // Recorder controls
    private lateinit var cgRecRes: ChipGroup
    private lateinit var cgRecFps: ChipGroup
    private lateinit var sbRecBitrate: SeekBar
    private lateinit var tvRecBitrate: TextView
    private lateinit var swRecAudio: MaterialSwitch
    private lateinit var btnStartRecord: AppCompatButton
    private lateinit var btnStopRecord: AppCompatButton

    // TikTok controls
    private lateinit var webTikTok: WebView
    private lateinit var etTikTokServer: EditText
    private lateinit var etTikTokKey: EditText

    private var mirrorUrl = ""
    private var pendingMode = ScreenService.MODE_MIRROR

    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
            val data = r.data
            if (r.resultCode == RESULT_OK && data != null) {
                val i = Intent(this, ScreenService::class.java).apply {
                    putExtra("mode", pendingMode)
                    putExtra("code", r.resultCode)
                    putExtra("data", data)
                    if (pendingMode == ScreenService.MODE_MIRROR) {
                        putExtra("short", mirrorShortSide())
                        putExtra("fps", mirrorFps())
                        putExtra("quality", mirrorQuality())
                        putExtra("audio", swMirrorAudio.isChecked)
                    } else {
                        putExtra("short", recShortSide())
                        putExtra("fps", recFps())
                        putExtra("customBitrate", sbRecBitrate.progress * 1_000_000)
                        putExtra("audio", swRecAudio.isChecked)
                    }
                }
                ContextCompat.startForegroundService(this, i)
                syncUiState(true, pendingMode)
            }
        }

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { askProjection() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bindViews()
        setupNavigation()
        setupMirrorSection()
        setupRecorderSection()
        setupTikTokSection()

        syncUiState(ScreenService.isRunning, ScreenService.activeMode)
    }

    private fun bindViews() {
        panelMirror = findViewById(R.id.panelMirror)
        panelRecorder = findViewById(R.id.panelRecorder)
        panelTikTok = findViewById(R.id.panelTikTok)
        tvBadgeState = findViewById(R.id.tvBadgeState)

        iconNavMirror = findViewById(R.id.iconNavMirror)
        txtNavMirror = findViewById(R.id.txtNavMirror)
        iconNavRecorder = findViewById(R.id.iconNavRecorder)
        txtNavRecorder = findViewById(R.id.txtNavRecorder)
        iconNavTikTok = findViewById(R.id.iconNavTikTok)
        txtNavTikTok = findViewById(R.id.txtNavTikTok)

        cgMirrorRes = findViewById(R.id.cgMirrorRes)
        cgMirrorFps = findViewById(R.id.cgMirrorFps)
        cgMirrorQ = findViewById(R.id.cgMirrorQ)
        swMirrorAudio = findViewById(R.id.swMirrorAudio)
        tvMirrorEstimate = findViewById(R.id.tvMirrorEstimate)
        btnStartMirror = findViewById(R.id.btnStartMirror)
        btnStopMirror = findViewById(R.id.btnStopMirror)
        cardMirrorLink = findViewById(R.id.cardMirrorLink)
        tvMirrorUrl = findViewById(R.id.tvMirrorUrl)

        cgRecRes = findViewById(R.id.cgRecRes)
        cgRecFps = findViewById(R.id.cgRecFps)
        sbRecBitrate = findViewById(R.id.sbRecBitrate)
        tvRecBitrate = findViewById(R.id.tvRecBitrate)
        swRecAudio = findViewById(R.id.swRecAudio)
        btnStartRecord = findViewById(R.id.btnStartRecord)
        btnStopRecord = findViewById(R.id.btnStopRecord)

        webTikTok = findViewById(R.id.webTikTok)
        etTikTokServer = findViewById(R.id.etTikTokServer)
        etTikTokKey = findViewById(R.id.etTikTokKey)
    }

    private fun setupNavigation() {
        findViewById<View>(R.id.navMirror).setOnClickListener { selectTab(0) }
        findViewById<View>(R.id.navRecorder).setOnClickListener { selectTab(1) }
        findViewById<View>(R.id.navTikTok).setOnClickListener { selectTab(2) }
    }

    private fun selectTab(index: Int) {
        panelMirror.visibility = if (index == 0) View.VISIBLE else View.GONE
        panelRecorder.visibility = if (index == 1) View.VISIBLE else View.GONE
        panelTikTok.visibility = if (index == 2) View.VISIBLE else View.GONE

        val activeCyan = ContextCompat.getColor(this, R.color.ios_cyan)
        val activePink = ContextCompat.getColor(this, R.color.tiktok_pink)
        val inactive = ContextCompat.getColor(this, R.color.text_secondary)

        iconNavMirror.setColorFilter(if (index == 0) activeCyan else inactive)
        txtNavMirror.setTextColor(if (index == 0) activeCyan else inactive)

        txtNavRecorder.setTextColor(if (index == 1) activeCyan else inactive)

        iconNavTikTok.setColorFilter(if (index == 2) activePink else inactive)
        txtNavTikTok.setTextColor(if (index == 2) activePink else inactive)
    }

    private fun mirrorShortSide() = when (cgMirrorRes.checkedChipId) {
        R.id.mr720 -> 720
        R.id.mr2k -> 1440
        R.id.mr4k -> 2160
        else -> 1080
    }

    private fun mirrorFps() = when (cgMirrorFps.checkedChipId) {
        R.id.mf30 -> 30
        R.id.mf90 -> 90
        R.id.mf120 -> 120
        else -> 60
    }

    private fun mirrorQuality() = when (cgMirrorQ.checkedChipId) {
        R.id.mq0 -> 0
        R.id.mq2 -> 2
        else -> 1
    }

    private fun setupMirrorSection() {
        val updater = ChipGroup.OnCheckedStateChangeListener { _, _ -> updateMirrorEstimate() }
        cgMirrorRes.setOnCheckedStateChangeListener(updater)
        cgMirrorFps.setOnCheckedStateChangeListener(updater)
        cgMirrorQ.setOnCheckedStateChangeListener(updater)
        updateMirrorEstimate()

        btnStartMirror.setOnClickListener {
            pendingMode = ScreenService.MODE_MIRROR
            checkPermissionsAndStart(swMirrorAudio.isChecked)
        }

        btnStopMirror.setOnClickListener {
            stopService(Intent(this, ScreenService::class.java))
            syncUiState(false, "")
        }

        findViewById<View>(R.id.btnCopyMirrorUrl).setOnClickListener {
            copyToClipboard("DZR CAST URL", mirrorUrl)
        }
    }

    private fun updateMirrorEstimate() {
        val (w, h) = ScreenService.calcSize(this, mirrorShortSide())
        val mbps = ScreenService.calcBitrate(w, h, mirrorFps(), mirrorQuality()) / 1_000_000
        tvMirrorEstimate.text = "$w×$h  •  ${mirrorFps()} FPS  •  ≈ $mbps Mbps"
    }

    private fun recShortSide() = when (cgRecRes.checkedChipId) {
        R.id.rr720 -> 720
        R.id.rr2k -> 1440
        R.id.rrNative -> 0
        else -> 1080
    }

    private fun recFps() = when (cgRecFps.checkedChipId) {
        R.id.rf30 -> 30
        R.id.rf90 -> 90
        R.id.rf120 -> 120
        else -> 60
    }

    private fun setupRecorderSection() {
        sbRecBitrate.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                tvRecBitrate.text = "معدل البت (Bitrate): $progress Mbps"
            }
            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        btnStartRecord.setOnClickListener {
            pendingMode = ScreenService.MODE_RECORD
            checkPermissionsAndStart(swRecAudio.isChecked)
        }

        btnStopRecord.setOnClickListener {
            stopService(Intent(this, ScreenService::class.java))
            syncUiState(false, "")
            Toast.makeText(this, "تم حفظ الفيديو في المعرض (Movies/DZR CAST) ✅", Toast.LENGTH_LONG).show()
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupTikTokSection() {
        CookieManager.getInstance().setAcceptCookie(true)
        webTikTok.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            databaseEnabled = true
            useWideViewPort = true
            loadWithOverviewMode = true
            userAgentString = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36"
        }

        webTikTok.webChromeClient = WebChromeClient()
        webTikTok.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                return false
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                scanWebForStreamKeys()
            }
        }

        findViewById<View>(R.id.btnOpenTikTokLogin).setOnClickListener {
            webTikTok.visibility = View.VISIBLE
            webTikTok.loadUrl("https://www.tiktok.com/live/creator-center/stream")
            Toast.makeText(this, "سجل الدخول بحسابك ثم اضغط (فحص الصفحة) بعد ظهور لوحة البث", Toast.LENGTH_LONG).show()
        }

        findViewById<View>(R.id.btnScanTikTokPage).setOnClickListener {
            scanWebForStreamKeys()
        }

        findViewById<View>(R.id.btnCopyServer).setOnClickListener {
            copyToClipboard("Server URL", etTikTokServer.text.toString())
        }

        findViewById<View>(R.id.btnCopyKey).setOnClickListener {
            copyToClipboard("Stream Key", etTikTokKey.text.toString())
        }

        findViewById<View>(R.id.btnCopyFullRtmp).setOnClickListener {
            val srv = etTikTokServer.text.toString().trim()
            val key = etTikTokKey.text.toString().trim()
            if (srv.isEmpty() || key.isEmpty()) {
                Toast.makeText(this, "لا يوجد مفتاح مستخرج بعد", Toast.LENGTH_SHORT).show()
            } else {
                val sep = if (srv.endsWith("/")) "" else "/"
                copyToClipboard("TikTok Full RTMP", "$srv$sep$key")
            }
        }
    }

    private fun scanWebForStreamKeys() {
        val js = """
            (function() {
                var srv = '';
                var key = '';
                var inputs = document.querySelectorAll('input, textarea, code, span, p');
                for (var i = 0; i < inputs.length; i++) {
                    var val = (inputs[i].value || inputs[i].innerText || '').trim();
                    if (val.indexOf('rtmp://') === 0 || val.indexOf('rtmps://') === 0) {
                        srv = val;
                    } else if (val.indexOf('stream-') === 0 && val.length > 12 && val.indexOf(' ') === -1) {
                        key = val;
                    }
                }
                return srv + '||' + key;
            })();
        """.trimIndent()

        webTikTok.evaluateJavascript(js) { res ->
            val cleaned = res?.replace(""", "") ?: ""
            if (cleaned.contains("||")) {
                val parts = cleaned.split("||")
                val foundSrv = parts[0].trim()
                val foundKey = if (parts.size > 1) parts[1].trim() else ""
                if (foundSrv.isNotEmpty()) etTikTokServer.setText(foundSrv)
                if (foundKey.isNotEmpty()) etTikTokKey.setText(foundKey)
                if (foundSrv.isNotEmpty() || foundKey.isNotEmpty()) {
                    Toast.makeText(this, "تم استخراج بيانات بث TikTok بنجاح ✅", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    private fun checkPermissionsAndStart(needAudio: Boolean) {
        val need = mutableListOf<String>()
        if (needAudio && Build.VERSION.SDK_INT >= 29 && !granted(Manifest.permission.RECORD_AUDIO)) {
            need += Manifest.permission.RECORD_AUDIO
        }
        if (Build.VERSION.SDK_INT >= 33 && !granted(Manifest.permission.POST_NOTIFICATIONS)) {
            need += Manifest.permission.POST_NOTIFICATIONS
        }
        if (need.isEmpty()) askProjection() else permLauncher.launch(need.toTypedArray())
    }

    private fun granted(p: String) =
        ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun askProjection() {
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun syncUiState(on: Boolean, mode: String) {
        btnStartMirror.isEnabled = !on
        btnStartRecord.isEnabled = !on
        btnStopMirror.isEnabled = on && mode == ScreenService.MODE_MIRROR
        btnStopRecord.isEnabled = on && mode == ScreenService.MODE_RECORD

        if (on) {
            if (mode == ScreenService.MODE_MIRROR) {
                tvBadgeState.text = "● يبث الآن"
                tvBadgeState.setTextColor(ContextCompat.getColor(this, R.color.ios_green))
                cardMirrorLink.visibility = View.VISIBLE
                mirrorUrl = "http://${localIp()}:${ScreenService.PORT}/live.ts"
                tvMirrorUrl.text = mirrorUrl
            } else {
                tvBadgeState.text = "● يسجل REC"
                tvBadgeState.setTextColor(ContextCompat.getColor(this, R.color.ios_red))
                cardMirrorLink.visibility = View.GONE
            }
        } else {
            tvBadgeState.text = "● جاهز"
            tvBadgeState.setTextColor(ContextCompat.getColor(this, R.color.ios_cyan))
            cardMirrorLink.visibility = View.GONE
        }
    }

    private fun copyToClipboard(label: String, text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText(label, text))
        Toast.makeText(this, "تم نسخ $label ✅", Toast.LENGTH_SHORT).show()
    }

    private fun localIp(): String {
        var fallback = ""
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (a in ni.inetAddresses) {
                    if (a is Inet4Address && !a.isLoopbackAddress) {
                        if (ni.name.startsWith("wlan") || ni.name.startsWith("ap")) return a.hostAddress ?: ""
                        if (fallback.isEmpty()) fallback = a.hostAddress ?: ""
                    }
                }
            }
        } catch (_: Exception) {}
        return fallback.ifEmpty { "0.0.0.0" }
    }
}
