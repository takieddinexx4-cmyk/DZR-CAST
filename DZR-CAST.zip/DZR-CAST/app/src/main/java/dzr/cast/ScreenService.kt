package dzr.cast

import android.annotation.SuppressLint
import android.app.*
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.MediaStore
import android.util.DisplayMetrics
import android.view.WindowManager
import java.io.File
import java.io.FileDescriptor
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.TimeUnit
import kotlin.math.max
import kotlin.math.min

class ScreenService : Service() {

    companion object {
        const val PORT = 8080
        const val MODE_MIRROR = "MIRROR"
        const val MODE_RECORD = "RECORD"

        private const val A_RATE = 48000
        private const val PTS_OFFSET_US = 200_000L

        @Volatile var isRunning = false
        @Volatile var activeMode = ""

        fun realSize(ctx: Context): Pair<Int, Int> {
            val wm = ctx.getSystemService(Context.WINDOW_SERVICE) as WindowManager
            return if (Build.VERSION.SDK_INT >= 30) {
                val b = wm.maximumWindowMetrics.bounds
                b.width() to b.height()
            } else {
                val m = DisplayMetrics()
                @Suppress("DEPRECATION") wm.defaultDisplay.getRealMetrics(m)
                m.widthPixels to m.heightPixels
            }
        }

        fun calcSize(ctx: Context, shortTarget: Int): Pair<Int, Int> {
            val (rw, rh) = realSize(ctx)
            if (shortTarget <= 0) return (rw / 16 * 16) to (rh / 16 * 16)
            val sh = min(rw, rh)
            val scale = min(shortTarget, sh).toFloat() / sh
            return ((rw * scale).toInt() / 16 * 16) to ((rh * scale).toInt() / 16 * 16)
        }

        fun calcBitrate(w: Int, h: Int, fps: Int, q: Int): Int {
            val bpp = doubleArrayOf(0.06, 0.10, 0.16)[q.coerceIn(0, 2)]
            return (w * h * fps * bpp).toInt().coerceIn(2_000_000, 100_000_000)
        }
    }

    private class Client(val sock: Socket) {
        val q = ArrayBlockingQueue<ByteArray>(150)
        @Volatile var needKey = true
        @Volatile var alive = true
    }

    private val mux = TsMuxer()
    private val clients = CopyOnWriteArrayList<Client>()
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var venc: MediaCodec? = null
    private var aenc: MediaCodec? = null
    private var rec: AudioRecord? = null
    private var server: ServerSocket? = null
    private var mediaMuxer: MediaMuxer? = null
    private var videoTrackIndex = -1
    private var audioTrackIndex = -1
    @Volatile private var muxerStarted = false

    @Volatile private var running = false
    private var startUs = 0L
    private var hasAudio = false
    private var currentMode = MODE_MIRROR

    override fun onBind(i: Intent?): IBinder? = null

    private fun nowUs() = System.nanoTime() / 1000

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || running) return START_NOT_STICKY

        currentMode = intent.getStringExtra("mode") ?: MODE_MIRROR
        startForegroundCompat(currentMode)

        val code = intent.getIntExtra("code", 0)
        val data = intent.getParcelableExtra<Intent>("data")
        val shortTarget = intent.getIntExtra("short", 1080)
        val fps = intent.getIntExtra("fps", 60)
        val quality = intent.getIntExtra("quality", 1)
        val customBitrate = intent.getIntExtra("customBitrate", 0)
        val wantAudio = intent.getBooleanExtra("audio", true)

        if (data == null) {
            stopSelf()
            return START_NOT_STICKY
        }

        try {
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            val proj = mgr.getMediaProjection(code, data)
            projection = proj
            proj.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, Handler(Looper.getMainLooper()))

            var w = 0
            var h = 0
            var enc: MediaCodec? = null
            val tiers = if (shortTarget <= 0) listOf(0, 1080, 720)
            else listOf(shortTarget, 1440, 1080, 720).filter { it <= shortTarget }.distinct()

            for (t in tiers) {
                val (tw, th) = calcSize(this, t)
                val br = if (customBitrate > 0) customBitrate else calcBitrate(tw, th, fps, quality)
                try {
                    enc = createVideoEncoder(tw, th, fps, br)
                    w = tw
                    h = th
                    break
                } catch (e: Exception) {
                    try { enc?.release() } catch (_: Exception) {}
                    enc = null
                }
            }

            if (enc == null) {
                stopSelf()
                return START_NOT_STICKY
            }

            val encoder: MediaCodec = enc
            venc = encoder
            val surface = encoder.createInputSurface()
            encoder.start()

            startUs = nowUs()
            hasAudio = wantAudio && startAudio(proj)

            if (currentMode == MODE_RECORD) {
                setupMp4Muxer()
            }

            display = proj.createVirtualDisplay(
                "DZR CASTPro", w, h, resources.displayMetrics.densityDpi,
                DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, surface, null, null
            )

            running = true
            isRunning = true
            activeMode = currentMode

            Thread { videoLoop(encoder) }.start()
            if (hasAudio) Thread { audioLoop() }.start()
            if (currentMode == MODE_MIRROR) Thread { serverLoop() }.start()

        } catch (e: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun setupMp4Muxer() {
        val fileName = "DZR CAST_${System.currentTimeMillis()}.mp4"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, fileName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/DZR CAST")
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
            if (uri != null) {
                val pfd = contentResolver.openFileDescriptor(uri, "w")
                if (pfd != null) {
                    val fd: FileDescriptor = pfd.fileDescriptor
                    mediaMuxer = MediaMuxer(fd, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
                }
            }
        } else {
            val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MOVIES), "DZR CAST")
            if (!dir.exists()) dir.mkdirs()
            val outFile = File(dir, fileName)
            mediaMuxer = MediaMuxer(outFile.absolutePath, MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
        }
    }

    @Synchronized
    private fun checkStartMuxer() {
        val m = mediaMuxer ?: return
        if (muxerStarted) return
        if (videoTrackIndex >= 0 && (!hasAudio || audioTrackIndex >= 0)) {
            m.start()
            muxerStarted = true
        }
    }

    private fun createVideoEncoder(w: Int, h: Int, fps: Int, bitrate: Int): MediaCodec {
        val f = MediaFormat.createVideoFormat(MediaFormat.MIMETYPE_VIDEO_AVC, w, h)
        f.setInteger(MediaFormat.KEY_COLOR_FORMAT, MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
        f.setInteger(MediaFormat.KEY_BIT_RATE, bitrate)
        f.setInteger(MediaFormat.KEY_FRAME_RATE, fps)
        f.setInteger(MediaFormat.KEY_I_FRAME_INTERVAL, 1)
        f.setInteger(MediaFormat.KEY_BITRATE_MODE, MediaCodecInfo.EncoderCapabilities.BITRATE_MODE_VBR)
        f.setInteger(MediaFormat.KEY_PRIORITY, 0)
        f.setLong(MediaFormat.KEY_REPEAT_PREVIOUS_FRAME_AFTER, 200_000L)
        val c = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_VIDEO_AVC)
        try {
            c.configure(f, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
        } catch (e: Exception) {
            c.release()
            throw e
        }
        return c
    }

    @SuppressLint("MissingPermission")
    private fun startAudio(proj: MediaProjection): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        if (checkSelfPermission(android.Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return false
        return try {
            val cfg = AudioPlaybackCaptureConfiguration.Builder(proj)
                .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                .addMatchingUsage(AudioAttributes.USAGE_GAME)
                .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                .build()
            val fmt = AudioFormat.Builder()
                .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                .setSampleRate(A_RATE)
                .setChannelMask(AudioFormat.CHANNEL_IN_STEREO)
                .build()
            val minBuf = AudioRecord.getMinBufferSize(A_RATE, AudioFormat.CHANNEL_IN_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord.Builder()
                .setAudioPlaybackCaptureConfig(cfg)
                .setAudioFormat(fmt)
                .setBufferSizeInBytes(max(minBuf * 2, 16384))
                .build()
            val af = MediaFormat.createAudioFormat(MediaFormat.MIMETYPE_AUDIO_AAC, A_RATE, 2)
            af.setInteger(MediaFormat.KEY_AAC_PROFILE, MediaCodecInfo.CodecProfileLevel.AACObjectLC)
            af.setInteger(MediaFormat.KEY_BIT_RATE, 256_000)
            af.setInteger(MediaFormat.KEY_MAX_INPUT_SIZE, 16384)
            val a = MediaCodec.createEncoderByType(MediaFormat.MIMETYPE_AUDIO_AAC)
            a.configure(af, null, null, MediaCodec.CONFIGURE_FLAG_ENCODE)
            a.start()
            aenc = a
            true
        } catch (e: Exception) {
            try { rec?.release() } catch (_: Exception) {}
            rec = null
            aenc = null
            false
        }
    }

    private fun videoLoop(enc: MediaCodec) {
        val info = MediaCodec.BufferInfo()
        var config: ByteArray? = null
        try {
            while (running) {
                val i = enc.dequeueOutputBuffer(info, 10_000)
                if (i == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && currentMode == MODE_RECORD) {
                    videoTrackIndex = mediaMuxer?.addTrack(enc.outputFormat) ?: -1
                    checkStartMuxer()
                    continue
                }
                if (i < 0) continue
                val buf = enc.getOutputBuffer(i)
                if (buf != null && info.size > 0) {
                    if (currentMode == MODE_RECORD) {
                        if (muxerStarted && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                            buf.position(info.offset)
                            buf.limit(info.offset + info.size)
                            synchronized(this) {
                                if (muxerStarted) mediaMuxer?.writeSampleData(videoTrackIndex, buf, info)
                            }
                        }
                    } else {
                        val d = ByteArray(info.size)
                        buf.position(info.offset)
                        buf.limit(info.offset + info.size)
                        buf.get(d)
                        if (info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG != 0) {
                            config = d
                        } else {
                            val key = info.flags and MediaCodec.BUFFER_FLAG_KEY_FRAME != 0
                            val el = nowUs() - startUs
                            val payload = if (key && config != null) config + d else d
                            var out = mux.pes(TsMuxer.VIDEO_PID, 0xE0, el + PTS_OFFSET_US, payload, el, key)
                            if (key) out = mux.pat() + mux.pmt(hasAudio) + out
                            broadcast(out, key, true)
                        }
                    }
                }
                enc.releaseOutputBuffer(i, false)
            }
        } catch (_: Exception) {}
    }

    private fun audioLoop() {
        val r = rec ?: return
        val a = aenc ?: return
        val pcm = ByteArray(4096)
        val info = MediaCodec.BufferInfo()
        var samples = 0L
        var base = -1L
        try {
            r.startRecording()
            while (running) {
                val n = r.read(pcm, 0, pcm.size)
                if (n <= 0) { Thread.sleep(5); continue }
                if (base < 0) base = nowUs() - startUs - (n / 4) * 1_000_000L / A_RATE
                val ii = a.dequeueInputBuffer(10_000)
                if (ii >= 0) {
                    val ib = a.getInputBuffer(ii)!!
                    ib.clear()
                    ib.put(pcm, 0, n)
                    a.queueInputBuffer(ii, 0, n, samples * 1_000_000L / A_RATE, 0)
                    samples += n / 4
                }
                while (true) {
                    val oi = a.dequeueOutputBuffer(info, 0)
                    if (oi == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED && currentMode == MODE_RECORD) {
                        audioTrackIndex = mediaMuxer?.addTrack(a.outputFormat) ?: -1
                        checkStartMuxer()
                        continue
                    }
                    if (oi < 0) break
                    val ob = a.getOutputBuffer(oi)
                    if (ob != null && info.size > 0 && info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG == 0) {
                        if (currentMode == MODE_RECORD) {
                            if (muxerStarted) {
                                ob.position(info.offset)
                                ob.limit(info.offset + info.size)
                                synchronized(this) {
                                    if (muxerStarted) mediaMuxer?.writeSampleData(audioTrackIndex, ob, info)
                                }
                            }
                        } else {
                            val len = info.size + 7
                            val frame = ByteArray(len)
                            frame[0] = 0xFF.toByte()
                            frame[1] = 0xF1.toByte()
                            frame[2] = ((1 shl 6) or (3 shl 2) or (2 shr 2)).toByte()
                            frame[3] = (((2 and 3) shl 6) or (len shr 11)).toByte()
                            frame[4] = ((len shr 3) and 0xFF).toByte()
                            frame[5] = (((len and 7) shl 5) or 0x1F).toByte()
                            frame[6] = 0xFC.toByte()
                            ob.position(info.offset)
                            ob.limit(info.offset + info.size)
                            ob.get(frame, 7, info.size)
                            val pts = base + info.presentationTimeUs + PTS_OFFSET_US
                            broadcast(mux.pes(TsMuxer.AUDIO_PID, 0xC0, pts, frame, null, false), false, false)
                        }
                    }
                    a.releaseOutputBuffer(oi, false)
                }
            }
        } catch (_: Exception) {}
    }

    private fun broadcast(d: ByteArray, key: Boolean, video: Boolean) {
        for (c in clients) {
            if (!c.alive) { clients.remove(c); continue }
            if (c.needKey) { if (video && key) c.needKey = false else continue }
            if (!c.q.offer(d)) { c.q.clear(); c.needKey = true; requestKey() }
        }
    }

    private fun requestKey() {
        try {
            venc?.setParameters(Bundle().apply { putInt(MediaCodec.PARAMETER_KEY_REQUEST_SYNC_FRAME, 0) })
        } catch (_: Exception) {}
    }

    private fun serverLoop() {
        try {
            val s = ServerSocket().apply { reuseAddress = true; bind(InetSocketAddress(PORT)) }
            server = s
            while (running) {
                val sock = s.accept()
                Thread { handleClient(sock) }.start()
            }
        } catch (_: Exception) {}
    }

    private fun handleClient(sock: Socket) {
        val c = Client(sock)
        try {
            sock.tcpNoDelay = true
            try { sock.sendBufferSize = 1 shl 20 } catch (_: Exception) {}
            val rd = sock.getInputStream().bufferedReader()
            val first = rd.readLine() ?: return
            while (true) { val l = rd.readLine() ?: break; if (l.isEmpty()) break }
            val out = sock.getOutputStream()
            if (first.contains("/live")) {
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: video/mp2t\r\nCache-Control: no-cache\r\n" +
                        "Connection: close\r\n\r\n").toByteArray())
                out.flush()
                clients.add(c)
                requestKey()
                while (running && c.alive) {
                    val d = c.q.poll(1, TimeUnit.SECONDS) ?: continue
                    out.write(d)
                    out.flush()
                }
            } else {
                val html = "<!DOCTYPE html><html dir=\"rtl\"><head><meta charset=\"utf-8\"><title>DZR CAST</title>" +
                        "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"></head>" +
                        "<body style=\"font-family:sans-serif;background:#07090E;color:#fff;text-align:center;padding:40px\">" +
                        "<h1>DZR CAST</h1><p>افتح هذا الرابط في VLC أو OBS:</p>" +
                        "<h2 dir=\"ltr\" style=\"color:#5AC8FA\">http://" + (sock.localAddress.hostAddress ?: "") + ":" + PORT + "/live.ts</h2></body></html>"
                val b = html.toByteArray()
                out.write(("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + b.size + "\r\n\r\n").toByteArray())
                out.write(b)
                out.flush()
            }
        } catch (_: Exception) {
        } finally {
            c.alive = false
            clients.remove(c)
            try { sock.close() } catch (_: Exception) {}
        }
    }

    private fun startForegroundCompat(mode: String) {
        val ch = "dzr_cast_pro"
        val nm = getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= 26)
            nm.createNotificationChannel(NotificationChannel(ch, "DZR CAST", NotificationManager.IMPORTANCE_LOW))
        val msg = if (mode == MODE_RECORD) "جاري تسجيل الشاشة وحفظ الفيديو..." else "البث المباشر يعمل على المنفذ $PORT"
        val n = Notification.Builder(this, ch)
            .setContentTitle("DZR CAST")
            .setContentText(msg)
            .setSmallIcon(R.drawable.ic_cast_hd)
            .build()
        if (Build.VERSION.SDK_INT >= 29)
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        else startForeground(1, n)
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        activeMode = ""
        for (c in clients) { c.alive = false; try { c.sock.close() } catch (_: Exception) {} }
        try { server?.close() } catch (_: Exception) {}
        try { display?.release() } catch (_: Exception) {}
        try { rec?.stop() } catch (_: Exception) {}
        try { rec?.release() } catch (_: Exception) {}
        try { aenc?.stop(); aenc?.release() } catch (_: Exception) {}
        try { venc?.stop(); venc?.release() } catch (_: Exception) {}
        synchronized(this) {
            if (muxerStarted) {
                try { mediaMuxer?.stop() } catch (_: Exception) {}
                muxerStarted = false
            }
            try { mediaMuxer?.release() } catch (_: Exception) {}
            mediaMuxer = null
        }
        try { projection?.stop() } catch (_: Exception) {}
        super.onDestroy()
    }
}
